# AWS VPC with public and private internet connectivity

Terraform deployment for AWS GovCloud (`us-gov-west-1`) by default. Change `aws_region` in `terraform.tfvars` for commercial AWS.

Creates:
- One VPC with DNS support/hostnames enabled
- Two public and two private subnets across two Availability Zones
- One Internet Gateway
- One public NAT Gateway with Elastic IP (shared by both private subnets)
- Public and private route tables and associations
- Public and private security groups

## Prerequisites
- Terraform >= 1.5
- AWS credentials and permissions to provision VPC/networking resources
- At least two available AZs in the selected region

## Deploy
```bash
aws sts get-caller-identity
terraform init
terraform fmt -check
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
terraform output
```

## Verify NAT
```bash
aws ec2 describe-nat-gateways --nat-gateway-ids "$(terraform output -raw nat_gateway_id)" --region us-gov-west-1
```

To test actual internet access, launch a suitable EC2 instance in a private subnet with SSM Session Manager connectivity (via required endpoints or other working SSM connectivity), then run `curl -4 https://checkip.amazonaws.com`. Output should equal `terraform output -raw nat_public_ip`.

## Security and production notes
- No EC2 instances are created by this configuration.
- The public SG permits inbound TCP 443 from anywhere, but does not permit SSH or RDP.
- Default IPv4 egress is unrestricted; tighten to meet policy.
- Private workloads cannot be reached directly from the internet via the NAT Gateway.
- The single NAT Gateway is a shared dependency and potentially incurs cross-AZ data fees. Use one NAT Gateway per AZ for resilient production designs.
- NAT Gateway usage and public IPv4 addresses incur AWS charges.
- This example relies on VPC default NACL and DHCP options; it does not create flow logs, endpoint services, or central egress inspection.
- For government environments, review required approved egress paths, STIG controls, and logging.
- Use a secure remote Terraform state backend for team deployment.

## Destroy
```bash
terraform destroy
```
